package com.yedam.java.app;

import java.util.Scanner;



public class MainExample {

	
	public static void main(String[] args) {

		new UserFrame().run();
	
	}
	
}
