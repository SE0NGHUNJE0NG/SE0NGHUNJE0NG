package com.yedam.tfprj.admin.community.service.faq;

import lombok.Data;

@Data
public class AdmFaqVO {
    private int     aNo;
    private String  title;
    private String  subTitle;
    private String  details;


}
