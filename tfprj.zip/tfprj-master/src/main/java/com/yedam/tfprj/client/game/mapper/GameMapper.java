package com.yedam.tfprj.client.game.mapper;

public interface GameMapper {
}
