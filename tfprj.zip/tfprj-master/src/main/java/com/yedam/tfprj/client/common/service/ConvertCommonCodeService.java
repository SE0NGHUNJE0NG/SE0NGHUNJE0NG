package com.yedam.tfprj.client.common.service;

public interface ConvertCommonCodeService {

    public CodeVO convertCode(String code);

}
