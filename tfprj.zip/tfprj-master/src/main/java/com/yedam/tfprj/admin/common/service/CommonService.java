package com.yedam.tfprj.admin.common.service;

public interface CommonService {

   }
