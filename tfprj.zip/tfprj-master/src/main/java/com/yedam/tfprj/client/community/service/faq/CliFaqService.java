package com.yedam.tfprj.client.community.service.faq;

import java.util.List;

public interface CliFaqService {
    public List<CliFaqVO> CliFaqList(CliFaqVO vo);
}
