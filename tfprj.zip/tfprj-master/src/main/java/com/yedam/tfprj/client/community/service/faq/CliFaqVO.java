package com.yedam.tfprj.client.community.service.faq;

import lombok.Data;

@Data
public class CliFaqVO {
    private int     aNo;
    private String  title;
    private String  subTitle;
    private String  details;
}
