package com.yedam.tfprj.client.message.service;

import lombok.Data;

@Data
public class ResMsgVO {

    private String resDate;
    private String status;
    private String resId;

}
