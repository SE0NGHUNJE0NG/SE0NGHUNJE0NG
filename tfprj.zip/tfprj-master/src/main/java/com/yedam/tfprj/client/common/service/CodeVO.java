package com.yedam.tfprj.client.common.service;

import lombok.Data;

@Data
public class CodeVO {

    private String codeValueId;
    private String codeName;
    private String codeValue;
    private String codeSort;
    private int codeYn;

}
