package com.yedam.tfprj.admin.common.mapper;

import com.yedam.tfprj.admin.workerAttendance.service.WorkerAttendanceVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CommonMapper {


}
