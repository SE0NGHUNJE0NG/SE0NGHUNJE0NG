package com.yedam.tfprj.admin.todo.Service;

import lombok.Data;

@Data
public class CheckVO {
    private int chkNo;
    private int isChk;
    private String workerId;
}
