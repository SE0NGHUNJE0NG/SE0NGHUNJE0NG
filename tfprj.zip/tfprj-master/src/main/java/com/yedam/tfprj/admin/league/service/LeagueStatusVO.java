package com.yedam.tfprj.admin.league.service;

import lombok.Data;

@Data
public class LeagueStatusVO {

    private int leagueStatusId;
    private int leagueStatus;
    private int leagueId;
    private String teamId;

}
